import pygame
import asyncio
import sys

pygame.init()

# Bildschirm
s = pygame.display.set_mode((800, 400))
pygame.display.set_caption("Mein Spiel")
c = pygame.time.Clock()

# --- Bilder laden ---
boden = pygame.image.load("pixil-frame-0 (33).png").convert_alpha()
boden_r = boden.get_rect(topleft=(0, 0))

standd = pygame.image.load("pixil-frame-8 (1).png").convert_alpha()
standa = pygame.image.load("pixil-frame-8 (2).png").convert_alpha()
stands = pygame.image.load("pixil-frame-0 (40).png").convert_alpha()
standw = pygame.image.load("pixil-frame-0 (41).png").convert_alpha()

walkd = [
    pygame.image.load("pixil-frame-0 (38).png").convert_alpha(),
    pygame.image.load("pixil-frame-1 (5).png").convert_alpha(),
    pygame.image.load("pixil-frame-2 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-3 (3).png").convert_alpha(),
    pygame.image.load("pixil-frame-4 (1).png").convert_alpha(),
    pygame.image.load("pixil-frame-5 (1).png").convert_alpha(),
    pygame.image.load("pixil-frame-6 (1).png").convert_alpha(),
    pygame.image.load("pixil-frame-7 (1).png").convert_alpha()
]

walka = [
    pygame.image.load("pixil-frame-0 (39).png").convert_alpha(),
    pygame.image.load("pixil-frame-1 (6).png").convert_alpha(),
    pygame.image.load("pixil-frame-2 (5).png").convert_alpha(),
    pygame.image.load("pixil-frame-3 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-4 (2).png").convert_alpha(),
    pygame.image.load("pixil-frame-5 (2).png").convert_alpha(),
    pygame.image.load("pixil-frame-6 (2).png").convert_alpha(),
    pygame.image.load("pixil-frame-7 (2).png").convert_alpha(),
]

walks = [
    pygame.image.load("pixil-frame-1 (7).png").convert_alpha(),
    pygame.image.load("pixil-frame-2 (6).png").convert_alpha(),
    pygame.image.load("pixil-frame-3 (5).png").convert_alpha(),
    pygame.image.load("pixil-frame-4 (3).png").convert_alpha(),
    pygame.image.load("pixil-frame-5 (3).png").convert_alpha(),
    pygame.image.load("pixil-frame-6 (3).png").convert_alpha(),
    pygame.image.load("pixil-frame-7 (3).png").convert_alpha(),
    pygame.image.load("pixil-frame-7 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-8 (3).png").convert_alpha()
]

walkw = [
    pygame.image.load("pixil-frame-1 (8).png").convert_alpha(),
    pygame.image.load("pixil-frame-2 (7).png").convert_alpha(),
    pygame.image.load("pixil-frame-3 (6).png").convert_alpha(),
    pygame.image.load("pixil-frame-4 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-5 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-6 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-7 (5).png").convert_alpha(),
    pygame.image.load("pixil-frame-8 (4).png").convert_alpha(),
    pygame.image.load("pixil-frame-9.png").convert_alpha()
]

# --- Inventory ---
inventory_surface = pygame.Surface((500, 300))
inventory_surface.fill("grey")

# --- Variablen ---
current_walkd = 0
current_walka = 0
current_walks = 0
current_walkw = 0

state = "idle_right"
game_movement = True
inventory = False

start_time = pygame.time.get_ticks()
speed = 5


async def main():
    global current_walkd, current_walka, current_walks, current_walkw
    global start_time, inventory, game_movement, state

    running = True

    while running:
        # -------- EVENTS --------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # INVENTORY TOGGLE (einmal pro Tastendruck)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_e and game_movement:
                    inventory = True
                    game_movement = False
                elif event.key == pygame.K_SPACE and inventory:
                    inventory = False
                    game_movement = True

        keys = pygame.key.get_pressed()

        # -------- BEWEGUNG --------
        moving = False

        if game_movement:
            if keys[pygame.K_a]:
                boden_r.x += speed
                state = "walk_left"
                moving = True

            elif keys[pygame.K_d]:
                boden_r.x -= speed
                state = "walk_right"
                moving = True

            elif keys[pygame.K_w]:
                boden_r.y += speed
                state = "walk_up"
                moving = True

            elif keys[pygame.K_s]:
                boden_r.y -= speed
                state = "walk_down"
                moving = True

        # -------- IDLE STATE --------
        if not moving:
            if state == "walk_left":
                state = "idle_left"
            elif state == "walk_right":
                state = "idle_right"
            elif state == "walk_up":
                state = "idle_up"
            elif state == "walk_down":
                state = "idle_down"

        # -------- ANIMATION --------
        if pygame.time.get_ticks() - start_time >= 100:
            if state == "walk_left":
                current_walka = (current_walka + 1) % len(walka)
            elif state == "walk_right":
                current_walkd = (current_walkd + 1) % len(walkd)
            elif state == "walk_down":
                current_walks = (current_walks + 1) % len(walks)
            elif state == "walk_up":
                current_walkw = (current_walkw + 1) % len(walkw)

            start_time = pygame.time.get_ticks()

        # -------- BOUNDARIES --------
        if boden_r.right < 575:
            boden_r.right = 575
        if boden_r.left > 300:
            boden_r.left = 300
        if boden_r.bottom < 375:
            boden_r.bottom = 375
        if boden_r.top > 102:
            boden_r.top = 102

        # -------- ZEICHNEN --------
        s.fill("black")
        s.blit(boden, boden_r)

        if state == "walk_right":
            s.blit(walkd[current_walkd], (400, 200))
        elif state == "idle_right":
            s.blit(standd, (400, 200))
        elif state == "walk_left":
            s.blit(walka[current_walka], (400, 200))
        elif state == "idle_left":
            s.blit(standa, (400, 200))
        elif state == "walk_down":
            s.blit(walks[current_walks], (400, 200))
        elif state == "idle_down":
            s.blit(stands, (400, 200))
        elif state == "walk_up":
            s.blit(walkw[current_walkw], (400, 200))
        elif state == "idle_up":
            s.blit(standw, (400, 200))

        if inventory:
            s.blit(inventory_surface, (150, 50))

        pygame.display.update()
        c.tick(60)

        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
